package org.cvm4j.cvm4j;

// Imports needed for HTTP/WS server
import com.sun.net.httpserver.HttpContext;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;

// File related imports
import java.io.IOException;
import java.io.OutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import sun.misc.IOUtils;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Arrays;

// WebSocket imports
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

// Misc imports


public class http {
    public static void main(String[] args) throws IOException {
        System.out.println("[!] You are running a beta! Performance and stability is probably not optimal.");
        System.out.println("[i] cvm4j beta build 0.3.1 (built 1/18/2022) is starting up...");
        System.out.println("[i] Thanks to MDMCK10 for helping with this release!");
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("[i] HTTP Server: localhost:3400");
        System.out.println("[i] WebSocket Server: localhost:3401");
        System.out.println("[i] It is normal if you get a 404 error on the WebSocket server.");
        System.out.println("[i] Using a Chromium based browser? You will need to allow insecure WebSocket connections to localhost if you want to access the VM.");
        httpstart();
        WebSocketServer srv = new WebsocketServer(new InetSocketAddress("0.0.0.0", 3401));
        srv.run();
    }

    private static void handleRequest(HttpExchange exchange) throws IOException {
        InputStream data = org.cvm4j.cvm4j.http.class.getResourceAsStream("/org/cvm4j/cvm4j/www/index.html");
        ByteArrayOutputStream result = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        for (int length; (length = data.read(buffer)) != -1; ) {
            result.write(buffer, 0, length);
        }

        String response = result.toString("UTF-8");
        exchange.sendResponseHeaders(200, response.getBytes().length); // Return status and length.
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }

    public static void httpstart() throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(3400), 0);
        HttpContext context = server.createContext("/");
        context.setHandler(http::handleRequest);
        server.start();
    }

    public static class GuacUtil {
    }
}
